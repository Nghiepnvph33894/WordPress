<?php

ux_builder_add_component( 'component_id', array(
  'name' => __( 'My component' ),
  'content' => '
    [title]My component[/title]
    [divider]
    [button text="Click component"]
  '
) );
